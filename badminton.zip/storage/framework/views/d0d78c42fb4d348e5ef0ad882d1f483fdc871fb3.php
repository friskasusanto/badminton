<head>
	<meta name="description" content="Brisbane badminton sport club &amp; klub olahraga badminton Brisbane Australia, CPLUSco Badminton Brisbane">
  	<title>CPLUSco Badminton Brisbane</title>
  	
	<meta charset="utf-8"/>
	<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="keywords" content="Sport,Olahraga,Badminton,Bulutangkis,CPLUSco,Semarang,Brisbane,Jawa Tengah,Health,Club,lifestyle,PB">
	<meta name="author" content="CPLUSco Connect">
	<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,500,600,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/reset.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" media="(max-width: 1023px)" href="<?php echo e(asset('css/max-1024px.css')); ?>">
	<link rel="stylesheet" media="(max-width: 768px)" href="<?php echo e(asset('css/max-768px.css')); ?>">
	<link rel="stylesheet" media="(max-width: 640px) and (orientation: portrait)" href="<?php echo e(asset('css/max-640px-portrait.css')); ?>">
	<link rel="stylesheet" media="(max-width: 640px) and (orientation: landscape)" href="<?php echo e(asset('css/max-640px-landscape.css')); ?>">
	<link rel="stylesheet" media="(min-width: 1024px)" href="<?php echo e(asset('css/min-1280px.css')); ?>">
	<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.css"/>
</head><?php /**PATH C:\badminton\resources\views/layout/html.blade.php ENDPATH**/ ?>