
<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>


<body id="about">
  <?php echo $__env->make('layout.php.analyticstracking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <aside class="side-nav">
    <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  </aside>

	<section > 
		<div class="logo">
	  		<div>
			    <div>
			    	<a href="<?php echo e(url('/home')); ?>">
			    		<img src="<?php echo e(url('images/logos.png')); ?>" alt="CPLUSco Badminton" class="img-logo">
			    		<img src="<?php echo e(url('images/logos-white.png')); ?>" alt="CPLUSco Badminton" class="img-logo-white">
			    	</a>
			    </div>
			</div>
		</div>

	<!-- document content -->
	  <div class="header">
	   <div class="title-header"> 
	   	<div>More Than Just A Team</div>
	   </div>
	  </div>
	  <div class="section about">
	    <div class="row">
	      <div class="col-sm-9">
	        <h4><strong>The Team</strong></h4>
	        <p><strong>CPLUSco Badminton Inc</strong>&nbsp;is a premier social badminton club for motivated Professionals, 
	        Business persons and Students across different fields. 
	        As a progressive club, we strive to become sporting and networking environment which create stimulating, 
	        enriching atmosphere for badminton players from various backgrounds and skill levels.
	        </p>
	        <p>
	        In CPLUSco Badminton we promote and facilitate participation in badminton at all levels.
	        </p>
	      </div>
	    </div>
	  </div>
	  <div class="section gallery">
	    <div class="row">
	      <div id="gallery" class="col-xs-12" data-get="img" data-url="gallery-mode.php" 
	      data-done="galleryOn" data-fail="galleryOff">
	        <h4><strong>Gallery</strong></h4>
	        <div class="swipe-nav">
	          <span class="glyphicon glyphicon-chevron-left"></span>
	          <span class="glyphicon glyphicon-chevron-left"></span>
	          <span class="glyphicon glyphicon-chevron-left"></span>
	          &nbsp;&nbsp;<em>swipe to navigate</em>&nbsp;&nbsp;
	          <span class="glyphicon glyphicon-chevron-right"></span>
	          <span class="glyphicon glyphicon-chevron-right"></span>
	          <span class="glyphicon glyphicon-chevron-right"></span>
	        </div>
	        <div class="autoplay">
	          <?php echo $__env->make('layout.php.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	        </div>
	      </div>
	    </div>
	  </div>
	</section>

	<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  	<?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  	<?php echo $__env->yieldContent('script'); ?>

</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', ['active' => 'about'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\badminton\resources\views/about.blade.php ENDPATH**/ ?>