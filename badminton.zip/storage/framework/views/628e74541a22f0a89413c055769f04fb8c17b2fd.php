
<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('content'); ?>


<body id="contact">
  <?php echo $__env->make('layout.php.analyticstracking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <aside class="side-nav">
    <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  </aside>

<section > 
  <div class="logo">
    <div>
      <div>
        <a href="<?php echo e(url('/home')); ?>">
          <img src="<?php echo e(url('images/logos.png')); ?>" alt="CPLUSco Badminton" class="img-logo">
          <img src="<?php echo e(url('images/logos-white.png')); ?>" alt="CPLUSco Badminton" class="img-logo-white">
        </a>
      </div>
    </div>
  </div>

  <!-- document content -->
  <div class="header">
    <div class="title-header"> 
      <div>Get In Touch With Us</div>
    </div>
  </div>
  <div class="section">
      <div class="contact">
        <div class="contact-boxes">
          <h4><strong>Brisbane, AU</strong></h4>
          <p class="contact-words">For sponsorship, advertising and general enquiries. Contact our office:</p>
          <address>
            <p>
              <span class="contact-office">CPLUSco - Badminton Division</span><br>
              CPLUSco Pty Ltd.,<br>
              Riparian Plaza - Level 36 <br> 
              71 Eagle St.<br>     
              Brisbane QLD 4000<br>   
              AUSTRALIA 
            </p>
            <p>
              P : <a href="tel:+61731213265">+61 7 3121 3265</a><br>
              F : <a href="tel:+61731213030">+61 7 3121 3030</a><br>        
              E : <a href="mailto:badminton@cplusco.com" target="_blank">badminton@cplusco.com</a>
            </p>
            <p>
              Facebook : <a href="https://www.facebook.com/badminton.cplusco/" target="_blank">CPLUSco Badminton Brisbane</a>
            </p>
          </address>
          <address>
            <p>Direct enquiries:<br>Rynaldo Wahyudi,<br>M : <a href="tel:+61413226610">+61 413 226 610</a></p>
          </address>
        </div>
      </div>
  </div>
</section>


  <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('script'); ?>

</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', ['active' => 'contact'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\badminton\resources\views/contact.blade.php ENDPATH**/ ?>