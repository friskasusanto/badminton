<footer>
  <div class="footer footer-child footer-copyright">
    © 2015 - 2016 Cplusco Connect - Some Rights Reserved
  </div>
</footer><?php /**PATH C:\badminton\resources\views/layout/footer.blade.php ENDPATH**/ ?>