<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-AU" class="">

	<?php echo $__env->make('layout.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



	<?php echo $__env->yieldContent('content'); ?>

	
</html>
<?php /**PATH C:\badminton\resources\views/layout/index.blade.php ENDPATH**/ ?>