<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


<body id="home">
  <?php echo $__env->make('layout.php.analyticstracking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <aside class="side-nav">
    <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  </aside>

<section > 
  <div class="logo">
    <div>
      <div>
        <a href="<?php echo e(url('/home')); ?>">
          <img src="<?php echo e(url('images/logos.png')); ?>" alt="CPLUSco Badminton" class="img-logo">
          <img src="<?php echo e(url('images/logos-white.png')); ?>" alt="CPLUSco Badminton" class="img-logo-white">
        </a>
      </div>
    </div>
  </div>
  <!-- document content -->
  <!-- flash ads -->
    <div class="section">
      <div class="landingFlash">
        <!-- flash content -->
          <div>
            <div class="block">
              <div class="table responsive flash-1"> 
                <div class="table-cell">
                  <h4>COME AND JOIN US</h4>
                  <p>CPLUSco Badminton Inc is a premier social badminton club for motivated Professionals, Business persons and Students across different fields</p>
                  <a class="flash-button" href="<?php echo e(url('/venue')); ?>" title="CPLUSco Badminton Brisbane Tournament">Session times</a>
                  <a class="flash-button" href="<?php echo e(url('/membership')); ?>" title="CPLUSco Badminton Brisbane Tournament">learn more</a>
                </div>
              </div>
            </div>
          </div>
        <!-- flash content -->
          <div>
            <div class="block">
              <div class="table responsive flash-3"> 
                <div class="table-cell">
                  <h4>Fun and competitive</h4>
                  <p>In CPLUSco Badminton we promote and facilitate participation in badminton at all levels</p>
                  <a class="flash-button" href="<?php echo e(url('/turnament')); ?>" title="CPLUSco Badminton Brisbane Tournament">Join Tournament</a>
                </div>
              </div>
            </div>
          </div>
        <!-- flash content -->
          <div>
            <div class="block">
              <div class="table responsive flash-2"> 
                <div class="table-cell">
                  <img src="<?php echo e(url('images/evolve.png')); ?>" alt="CPLUSco Badminton Training">
                  <h4>Begin your evolution</h4>
                  <p>We provide every step you need to become a badminton hero</p>
                  <a class="flash-button" href="<?php echo e(url('/training')); ?>" title="CPLUSco Badminton Brisbane Training">Join class</a>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
    <div class="section facebook-news">
      <div class="facebook-news-header">
        <h4><strong>Facebook News</strong></h4>
        For more info please visit our <a href="https://www.facebook.com/badminton.cplusco/" target="_blank" title="CPLUSco Badminton Brisbane facebook page">CPLUSco Badminton Brisbane</a> facebook page
        <div class="swipe-nav">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="glyphicon glyphicon-chevron-left"></span>
          &nbsp;&nbsp;<em>swipe to navigate</em>&nbsp;&nbsp;
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="glyphicon glyphicon-chevron-right"></span>
        </div>
      </div>
      <?php echo $__env->make('layout.brisbane', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- partners -->
    <div class="section">
      <div class="partners">
        <div class="text-center">
          <div class="partners-title center">PARTNERS</div>
            <div class="partners-img partners-living">
              <a target="_blank" href="http://living.cplusco.com" data-ads="living" class="__ads_click_">
              </a>
            </div>
            <div class="partners-img partners-energy">
              <a target="_blank" href="http://energy.cplusco.com" data-ads="energy" class="__ads_click_">
              </a>
            </div>
            <div class="partners-img partners-hillside">
              <a target="_blank" href="http://www.hillsideresidences.com.au" data-ads="hillside" class="__ads_click_">
              </a>
            </div>
            <div class="partners-img partners-etax">
              <a target="_blank" href="http://www.etaxlocal.com.au" data-ads="etax" class="__ads_click_">
              </a>
            </div>
            <div class="partners-img partners-getasean">
              <a target="_blank" href="http://www.getasean.com" data-ads="getasean" class="__ads_click_">
              </a>
            </div>
          <div class="partners-img"></div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('script'); ?>

</body>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
  $(document).ready(function(){
      $('.landingFlash').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 6000,
          arrows: true,   
          dots: false,
          infinite: true,
          // speed: 1000,
          fade: true,
          cssEase: 'linear',
          pauseOnHover:false,
    });
      slickArrows();
  });
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.index', ['active' => 'home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\badminton\resources\views/home.blade.php ENDPATH**/ ?>